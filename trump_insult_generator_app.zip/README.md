# Trump Insult Generator

A standalone mobile-friendly web app.

## iPhone
1. Put these files on a web host (GitHub Pages, Netlify, Vercel, etc.).
2. Open the site's `index.html` URL in Safari.
3. Tap Share -> Add to Home Screen.

The app works as a standalone home-screen web app after installation.

## Important
This is a parody generator. Generated combinations should not be treated as quotations from Donald Trump.
